# Shape Calculator

**Video Demo:** [Watch the demo](https://youtu.be/4yEe7Dhk5b0)

**Description:**
The Shape Calculator is a Python program that allows users to perform geometric calculations for rectangles, squares, and triangles through a simple command-line interface.
