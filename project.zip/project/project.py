import sys
import math

print("Name: IMROZ QAMAR MIRZA")
print("City: Ratlam")
print("Country: INDIA")

def main():
    print("Shape Calculator")
    print("Select a shape:")
    print("1. Rectangle")
    print("2. Square")
    print("3. Triangle")
    print("4. Quit")

    choice = input("Enter your choice (1/2/3/4): ")

    if choice == '1':
        width = float(input("Enter the width of the rectangle: "))
        height = float(input("Enter the height of the rectangle: "))
        calculate_rectangle(width, height)
    elif choice == '2':
        side_length = float(input("Enter the side length of the square: "))
        calculate_square(side_length)
    elif choice == '3':
        base = float(input("Enter the base length of the triangle: "))
        height = float(input("Enter the height of the triangle: "))
        calculate_triangle(base, height)
    elif choice == '4':
        print("Exiting the program. Goodbye!")
        sys.exit()
    else:
        print("Invalid choice")

def calculate_rectangle(width, height):
    area = width * height
    perimeter = 2 * (width + height)
    print(f"The area of the rectangle is {area}")
    print(f"The perimeter of the rectangle is {perimeter}")

def calculate_square(side_length):
    area = side_length ** 2
    perimeter = 4 * side_length
    print(f"The area of the square is {area}")
    print(f"The perimeter of the square is {perimeter}")

def calculate_triangle(base, height):
    area = 0.5 * base * height
    # Perimeter calculation is not straightforward, so let's leave it out for now.
    print(f"The area of the triangle is {area}")
    print("Note: Perimeter calculation for triangles is not included in this program.")

if __name__ == "__main__":
    while True:
        main()
        another_calculation = input("Do you want to perform another calculation? (yes/no): ")
        if another_calculation.lower() != 'yes':
            print("Thank you, Goodbye!")
            break
